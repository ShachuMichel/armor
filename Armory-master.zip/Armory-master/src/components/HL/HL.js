import React from "react";

const HL = () => {
  return <div className="line"></div>;
};

export default HL;
